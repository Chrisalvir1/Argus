import './argus-brand-patch.js';
import { applyArgusFrontend } from './react-dist/argus-frontend.js?v=3.7.10&render=widget-editor';
applyArgusFrontend();
