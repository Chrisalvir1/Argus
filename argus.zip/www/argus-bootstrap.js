import './argus-brand-patch.js';
import { applyArgusFrontend } from './react-dist/argus-frontend.js?v=2.5.8';
applyArgusFrontend();
