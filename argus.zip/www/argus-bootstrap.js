import './argus-brand-patch.js';
import { applyArgusFrontend } from './react-dist/argus-frontend.js?v=2.9.158&render=safari-scroll-fixed-wallpaper';
applyArgusFrontend();
