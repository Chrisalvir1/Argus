import { applyArgusFrontend } from './react-dist/argus-frontend.js?v=2.2.94';
applyArgusFrontend();
