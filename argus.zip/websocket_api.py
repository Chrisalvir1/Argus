"""Validated WebSocket API for the Argus frontend panel with per-instance isolation."""
from __future__ import annotations

import base64
import copy
import datetime
import logging
import os
import time
import uuid

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers import area_registry as ar
from homeassistant.helpers import entity_registry as er
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.dispatcher import async_dispatcher_send

from .const import (
    DOMAIN, SIGNAL_CONFIG_UPDATED, CONF_ARMING_VOICE_ENABLED,
    CONF_ARMING_VOICE_TTS, CONF_ARMING_VOICE_PLAYERS,
    CONF_ARMING_VOICE_MESSAGE_START, CONF_ARMING_VOICE_MESSAGE_REMAINING,
    CONF_ARMING_VOICE_MESSAGE_LAST, CONF_ARMING_VOICE_MESSAGE_COMPLETE,
    CONF_ARMING_VOICE_MESSAGE_ARMED,
    CONF_ARMING_VOICE_MESSAGE_CANCELLED, CONF_ARMING_VOICE_MESSAGE_TRIGGERED,
    CONF_ARMING_VOICE_MESSAGE_ADDITIONAL_TRIGGERED,
    CONF_ARMING_VOICE_MESSAGE_ALARM_SENSOR_CLOSED,
)
from .security import PinAttemptLimiter, hash_pin, needs_rehash, validate_pin, verify_pin
from .auth import (
    ArgusAuthError,
    _get_ha_actor,
    _require_ha_admin,
    _require_argus_session,
    _require_argus_admin,
    _require_permission,
)
from .session import async_get_session_manager
from .arming_voice import _get_language
from .i18n import translate
from .voice_settings import merge_media_player_entities, resolve_voice_settings
from .storage import (
    async_append_audit_log,
    async_clear_audit_log,
    async_get_audit_log,
    async_load_ui_data,
    async_restore_ui_data,
    async_save_ui_data,
    async_sync_ha_profiles,
    _sanitize_users,
)

_LOGGER = logging.getLogger(__name__)
_VOICE_FIELDS = (
    CONF_ARMING_VOICE_ENABLED, CONF_ARMING_VOICE_TTS, CONF_ARMING_VOICE_PLAYERS,
    CONF_ARMING_VOICE_MESSAGE_START, CONF_ARMING_VOICE_MESSAGE_REMAINING,
    CONF_ARMING_VOICE_MESSAGE_LAST, CONF_ARMING_VOICE_MESSAGE_COMPLETE,
    CONF_ARMING_VOICE_MESSAGE_ARMED,
    CONF_ARMING_VOICE_MESSAGE_CANCELLED, CONF_ARMING_VOICE_MESSAGE_TRIGGERED,
    CONF_ARMING_VOICE_MESSAGE_ADDITIONAL_TRIGGERED,
    CONF_ARMING_VOICE_MESSAGE_ALARM_SENSOR_CLOSED,
)
_MAX_UPLOAD_BYTES = 50 * 1024 * 1024
_ALLOWED_MEDIA_EXTENSIONS = {
    ".avif", ".gif", ".heic", ".heif", ".jpeg", ".jpg", ".m4v",
    ".mov", ".mp4", ".png", ".webm", ".webp",
}
_SUPPORTED_DOMAINS = {
    "binary_sensor", "camera", "climate", "cover", "light", "lock",
    "media_player", "sensor", "siren", "switch", "alarm_control_panel",
    "input_boolean", "script", "fan",
}


def _limiter(hass: HomeAssistant, entry_id: str = "global") -> PinAttemptLimiter:
    key = f"{DOMAIN}_limiter_{entry_id}"
    return hass.data.setdefault(key, PinAttemptLimiter())

def _actor(connection) -> tuple[str, str]:
    # Legacy wrapper, prefer _get_ha_actor directly
    return _get_ha_actor(connection)


def _entry_by_id(hass: HomeAssistant, entry_id: str):
    for entry in hass.config_entries.async_entries(DOMAIN):
        if entry.entry_id == entry_id:
            return entry
    return None


def _resolve_entry_id(hass: HomeAssistant, entry_id: str | None) -> str | None:
    """Return entry_id as-is if provided, or auto-resolve when there is exactly one Argus entry.

    This ensures that WebSocket commands called without an explicit entry_id
    (e.g. from the panel JS) still read/write the correct per-instance storage
    instead of falling back to the legacy global key 'argus.ui'.
    """
    if entry_id:
        return entry_id
    entries = hass.config_entries.async_entries(DOMAIN)
    if len(entries) == 1:
        return entries[0].entry_id
    return None


def _media_player_entities(hass: HomeAssistant) -> list[dict[str, object]]:
    """List active and enabled registered media players for the voice editor."""
    registry = er.async_get(hass)
    return merge_media_player_entities(
        hass.states.async_all("media_player"),
        registry.entities.values(),
    )


def _redact_ui_data(data: dict) -> dict:
    """Return UI data without reusable credential hashes."""
    redacted = copy.deepcopy(data)
    users = redacted.get("users", [])
    if isinstance(users, list):
        for user in users:
            if isinstance(user, dict):
                user["pin_configured"] = bool(user.get("pin"))
                user.pop("pin", None)
                user["access_pin_configured"] = bool(user.get("access_pin_hash"))
                user.pop("access_pin_hash", None)
                user["master_pin_configured"] = bool(user.get("master_pin_hash"))
                user.pop("master_pin_hash", None)
    advanced = redacted.get("advanced")
    if isinstance(advanced, dict):
        advanced["guest_code_configured"] = bool(advanced.get("guest_code"))
        advanced.pop("guest_code", None)
        advanced["duress_pin_configured"] = bool(advanced.get("duress_pin"))
        advanced.pop("duress_pin", None)
    redacted.pop("runtime", None)
    return redacted





def _serialize_available_entities(hass: HomeAssistant) -> list[dict]:
    entity_reg = er.async_get(hass)
    area_reg = ar.async_get(hass)
    entities = []

    for state in hass.states.async_all():
        domain = state.entity_id.split(".", 1)[0]
        if domain not in _SUPPORTED_DOMAINS:
            continue

        entry = entity_reg.async_get(state.entity_id)
        if entry and entry.disabled_by:
            continue

        area_id = entry.area_id if entry else None
        if not area_id and entry and entry.device_id:
            from homeassistant.helpers import device_registry as dr
            dev_reg = dr.async_get(hass)
            dev = dev_reg.async_get(entry.device_id)
            if dev:
                area_id = dev.area_id

        area_name = None
        if area_id:
            area = area_reg.async_get_area(area_id)
            if area:
                area_name = area.name

        entities.append({
            "entity_id": state.entity_id,
            "name": state.attributes.get("friendly_name") or state.entity_id,
            "domain": domain,
            "device_class": state.attributes.get("device_class"),
            "state": state.state,
            "area": area_name,
            "icon": state.attributes.get("icon"),
            "device_id": entry.device_id if entry else None,
        })

    return entities


@callback
def async_register_websocket_api(hass: HomeAssistant) -> None:
    # New endpoints
    websocket_api.async_register_command(hass, ws_argus_login_bootstrap)
    websocket_api.async_register_command(hass, ws_argus_complete_first_run)
    websocket_api.async_register_command(hass, ws_argus_claim_legacy_administration)
    websocket_api.async_register_command(hass, ws_argus_verify_access_pin)
    websocket_api.async_register_command(hass, ws_argus_select_profile)
    websocket_api.async_register_command(hass, ws_argus_logout_profile)
    websocket_api.async_register_command(hass, ws_argus_perform_alarm_action)
    websocket_api.async_register_command(hass, ws_argus_get_ha_users)
    websocket_api.async_register_command(hass, ws_argus_get_ha_persons)
    websocket_api.async_register_command(hass, ws_argus_save_user_access_pin)
    websocket_api.async_register_command(hass, ws_argus_sync_presence_rules)
    websocket_api.async_register_command(hass, ws_argus_verify_master_pin_for_screen_unlock)

    from .media_websocket import ws_upload, ws_list, ws_delete
    # Private-media compatibility endpoints.
    websocket_api.async_register_command(hass, ws_upload)
    websocket_api.async_register_command(hass, ws_list)
    websocket_api.async_register_command(hass, ws_delete)

    # Existing endpoints
    websocket_api.async_register_command(hass, ws_argus_dashboard)
    websocket_api.async_register_command(hass, ws_argus_save_ui)
    websocket_api.async_register_command(hass, ws_argus_get_mode_config)
    websocket_api.async_register_command(hass, ws_argus_save_mode_config)
    websocket_api.async_register_command(hass, ws_argus_get_audit_log)
    websocket_api.async_register_command(hass, ws_argus_get_forensic_timeline)
    websocket_api.async_register_command(hass, ws_argus_get_stats)
    websocket_api.async_register_command(hass, ws_argus_clear_audit_log)
    websocket_api.async_register_command(hass, ws_argus_export_config)
    websocket_api.async_register_command(hass, ws_argus_restore_config)
    websocket_api.async_register_command(hass, ws_argus_save_advanced_config)
    websocket_api.async_register_command(hass, ws_argus_get_advanced_config)
    websocket_api.async_register_command(hass, ws_argus_save_automations)
    websocket_api.async_register_command(hass, ws_argus_get_automations)
    websocket_api.async_register_command(hass, ws_argus_get_zones)
    websocket_api.async_register_command(hass, ws_argus_save_zones)
    websocket_api.async_register_command(hass, ws_argus_get_voice_config)
    websocket_api.async_register_command(hass, ws_argus_save_voice_config)
    websocket_api.async_register_command(hass, ws_argus_get_media_players)
    websocket_api.async_register_command(hass, ws_argus_update_master_pin)
    websocket_api.async_register_command(hass, ws_argus_update_incident)
    websocket_api.async_register_command(hass, ws_argus_get_health)
    websocket_api.async_register_command(hass, ws_argus_import_alarmo)
    websocket_api.async_register_command(hass, ws_argus_get_profile_theme)
    websocket_api.async_register_command(hass, ws_argus_save_profile_theme)
    websocket_api.async_register_command(hass, ws_argus_validate_master_pin)
    websocket_api.async_register_command(hass, ws_argus_cycle_bypass)
    websocket_api.async_register_command(hass, ws_argus_subscribe_walk_test)
    websocket_api.async_register_command(hass, ws_argus_walk_test_step)
    websocket_api.async_register_command(hass, ws_argus_sensor_diagnosis)
    websocket_api.async_register_command(hass, ws_argus_start_walk_test)
    websocket_api.async_register_command(hass, ws_argus_stop_walk_test)
    websocket_api.async_register_command(hass, ws_argus_get_walk_test_status)


@websocket_api.websocket_command({
    vol.Required("type"): "argus/import_alarmo",
    vol.Required("alarmo_data"): dict,
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_import_alarmo(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    actor = profile.get("name", "Unknown")

    from .core.migration import AlarmoImporter
    preview = AlarmoImporter.preview_import(msg["alarmo_data"])
    if not preview.safe_to_import:
        connection.send_error(msg["id"], "invalid_alarmo_data", "Cannot import Alarmo payload")
        return

    argus_config = AlarmoImporter.generate_argus_config(msg["alarmo_data"])
    saved = await async_save_ui_data(hass, argus_config, entry_id)
    await async_append_audit_log(
        hass, "alarmo_imported", f"Imported {argus_config['migrated_sensors_count']} sensors from Alarmo", user=actor, entry_id=entry_id
    )
    async_dispatcher_send(hass, SIGNAL_CONFIG_UPDATED, entry_id)
    connection.send_result(msg["id"], {
        "success": True,
        "preview": {
            "supported_areas": preview.supported_areas,
            "supported_sensors": preview.supported_sensors,
            "incompatible_items": preview.incompatible_items,
        },
        "ui": _redact_ui_data(saved),
    })


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_forensic_timeline",
    vol.Optional("entry_id"): str,
    vol.Optional("limit", default=100): int,
})
@websocket_api.async_response
async def ws_argus_get_forensic_timeline(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_permission(hass, connection, entry_id, "view_history")
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    log = await async_get_audit_log(hass, entry_id)
    timeline = log[:msg["limit"]]
    connection.send_result(msg["id"], {"timeline": timeline})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_health",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_health(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    data = await async_load_ui_data(hass, entry_id)

    # Gather sensor and siren states
    states = {}
    for state in hass.states.async_all():
        states[state.entity_id] = {
            "state": state.state,
            "attributes": dict(state.attributes),
        }

    modes = data.get("modes", {})
    sensors = []
    for mode_cfg in modes.values():
        if isinstance(mode_cfg, dict):
            sensors.extend(mode_cfg.get("sensors") or [])

    from .core.health import evaluate_system_health
    report = evaluate_system_health(
        states_dict=states,
        configured_sensors=list(set(sensors)),
        siren_entity=data.get("siren_entity"),
        mqtt_enabled=bool(data.get("mqtt_enabled")),
    )
    connection.send_result(msg["id"], {
        "readiness_score": report.readiness_score,
        "status": report.status,
        "issues": [{"issue_id": i.issue_id, "severity": i.severity, "category": i.category, "message": i.message, "recommendation": i.recommendation} for i in report.issues],
        "recommendations": report.recommendations,
    })


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_incidents",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_incidents(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_permission(hass, connection, entry_id, "view_history")
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    data = await async_load_ui_data(hass, entry_id)
    incidents = data.get("incidents", [])
    connection.send_result(msg["id"], {"incidents": incidents})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/update_incident",
    vol.Required("incident_id"): str,
    vol.Required("action"): vol.In(["confirm", "false_alarm", "silence_siren", "resolve"]),
    vol.Optional("reason", default=""): str,
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_update_incident(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    actor = profile.get("name", "Unknown")
    action, incident_id = msg["action"], msg["incident_id"]

    data = await async_load_ui_data(hass, entry_id)
    incidents = copy.deepcopy(data.get("incidents", []))
    target_inc = None
    for inc in incidents:
        if inc.get("id") == incident_id:
            target_inc = inc
            break

    if not target_inc:
        connection.send_error(msg["id"], "not_found", "Incident not found")
        return

    if action == "confirm":
        target_inc["status"] = "confirmed"
    elif action == "false_alarm":
        target_inc["status"] = "false_alarm"
    elif action == "resolve":
        target_inc["status"] = "resolved"

    target_inc.setdefault("executed_actions", []).append({
        "action": action, "actor": actor, "reason": msg.get("reason"), "ts": datetime.datetime.now(datetime.timezone.utc).isoformat()
    })

    await async_save_ui_data(hass, {"incidents": incidents}, entry_id)
    await async_append_audit_log(
        hass, f"incident_{action}", f"Incident {incident_id} action: {action}", user=actor, entry_id=entry_id
    )
    connection.send_result(msg["id"], {"success": True, "incident": target_inc})


@callback
def _resolve_alarm_entity_id(hass: HomeAssistant, config_entry_id: str) -> str | None:
    registry = er.async_get(hass)
    for entity in registry.entities.values():
        if entity.config_entry_id == config_entry_id and entity.domain == "alarm_control_panel" and not entity.disabled_by:
            return entity.entity_id
    return None


_PROFILE_ALLOWLIST = {
    "id",
    "name",
    "role",
    "enabled",
    "permissions",
    "shared_kiosk_profile",
    "picture",
    "ha_user_id",
    "access_pin_configured",
    "pin_configured",
    "master_pin_configured",
}

def _redact_user_profile(profile: dict | None) -> dict | None:
    """Redact user profile using a strict allowlist of fields."""
    if not isinstance(profile, dict):
        return None
    p = copy.deepcopy(profile)
    p["access_pin_configured"] = bool(p.get("access_pin_hash") or p.get("access_pin_configured"))
    p["pin_configured"] = bool(p.get("pin") or p.get("pin_configured"))
    p["master_pin_configured"] = bool(p.get("master_pin_hash") or p.get("master_pin_configured"))
    return {k: v for k, v in p.items() if k in _PROFILE_ALLOWLIST}



@websocket_api.websocket_command({
    vol.Required("type"): "argus/dashboard",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_dashboard(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_permission(hass, connection, entry_id, "view_status")
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    ui_data = await async_load_ui_data(hass, entry_id)
    dashboard = ui_data.get("dashboard") if isinstance(ui_data, dict) else None
    if isinstance(dashboard, dict):
        from .dashboard_merge import repair_saved_layout_collisions

        layout, repaired = repair_saved_layout_collisions(dashboard.get("react_layout_v5"))
        if repaired and layout is not None:
            _LOGGER.warning("Repairing overlapping saved Argus dashboard widgets for entry %s", entry_id)
            ui_data = await async_save_ui_data(
                hass,
                {"dashboard": {"react_layout_v5": layout}},
                entry_id,
            )
    has_user_disarm_pin = any(
        isinstance(user, dict)
        and user.get("enabled", True)
        and user.get("permissions", {}).get("disarm", False)
        and (user.get("pin") or user.get("master_pin_hash") or user.get("access_pin_hash"))
        for user in ui_data.get("users", [])
    )
    entries = []
    for entry in hass.config_entries.async_entries(DOMAIN):
        entity_id = _resolve_alarm_entity_id(hass, entry.entry_id)
        state = hass.states.get(entity_id) if entity_id else None
        entries.append({
            "entry_id": entry.entry_id,
            "title": entry.title,
            "entity_id": entity_id,
            "state": state.state if state else "unavailable",
            "attributes": dict(state.attributes) if state else {},
            "pin_configured": bool(entry.options.get("code") or entry.data.get("code")),
            "user_pin_configured": has_user_disarm_pin,
        })
    try:
        profile, _ = await _require_argus_session(hass, connection, entry_id)
    except ArgusAuthError:
        profile = None

    connection.send_result(msg["id"], {
        "entry_id": entry_id,
        "entries": entries,
        "current_profile": _redact_user_profile(profile),
        "ui": _redact_ui_data(ui_data),
        "available_entities": _serialize_available_entities(hass),
    })


_SAVE_UI_SCHEMA = {
    vol.Required("type"): "argus/save_ui",
    vol.Optional("entry_id"): str,
    vol.Optional("zones"): list,
    vol.Optional("dashboard"): dict,
    vol.Optional("floorplan"): dict,
    vol.Optional("notif_targets"): list,
    vol.Optional("emergency_number"): vol.All(str, vol.Length(min=1, max=16), vol.Match(r"^[0-9+()\-\s]+$")),
    vol.Optional("panic_outputs"): list,
    vol.Optional("users"): list,
    vol.Optional("home_name"): vol.All(str, vol.Length(max=128)),
    vol.Optional("background_mode"): vol.In(["weather", "none", "photo", "collage", "video"]),
    vol.Optional("background_images"): list,
    vol.Optional("theme"): {
        vol.Optional("background_mode"): vol.In(["default", "weather", "none", "photo", "collage", "video"]),
        vol.Optional("background_file"): str,
    },
    vol.Optional("temperature_source"): str,
    vol.Optional("weather_source"): str,
    vol.Optional("intelligent_confirmation"): dict,
    vol.Optional("state_schedule"): list,
    vol.Optional("temp_alert_min"): vol.Any(None, vol.Coerce(float)),
    vol.Optional("temp_alert_max"): vol.Any(None, vol.Coerce(float)),
    vol.Optional("panel_bg_file"): str,
    vol.Optional("panel_bg_sound"): bool,
    vol.Optional("hub_bg_mode"): vol.In(["none", "image", "video"]),
    vol.Optional("hub_bg_file"): str,
    vol.Optional("hub_bg_sound"): bool,
    vol.Optional("clock_format"): vol.In(["auto", "12h", "24h"]),
    vol.Optional("language"): vol.Any(None, str),
    vol.Optional("manual_lang"): vol.Any(None, str),
}


@websocket_api.websocket_command(_SAVE_UI_SCHEMA)
@websocket_api.async_response
async def ws_argus_save_ui(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    actor = profile.get("name", "Unknown")
    updates = {key: copy.deepcopy(value) for key, value in msg.items() if key not in {"id", "type", "entry_id"}}
    _, actor = _actor(connection)
    ui_data = await async_load_ui_data(hass, entry_id)
    old_users = ui_data.get("users", [])
    try:
        if "users" in updates:
            updates["users"] = _sanitize_users(updates["users"])
        if "floorplan" in updates and isinstance(updates["floorplan"], dict):
            from .core.floorplan import validate_floorplan_schema
            updates["floorplan"] = validate_floorplan_schema(updates["floorplan"])
        saved = await async_save_ui_data(hass, updates, entry_id)
        
        if "users" in updates:
            new_user_ids = {u.get("id") for u in updates["users"]}
            deleted_user_ids = [u.get("id") for u in old_users if u.get("id") and u.get("id") not in new_user_ids]
            if deleted_user_ids:
                from .session import async_get_session_manager
                sm = async_get_session_manager(hass)
                for uid in deleted_user_ids:
                    sm.invalidate_all_for_argus_user(entry_id, uid)
    except ValueError as err:
        connection.send_error(msg["id"], "invalid_config", str(err))
        return
    async_dispatcher_send(hass, SIGNAL_CONFIG_UPDATED, entry_id)
    await async_append_audit_log(hass, "ui_configuration_updated", user=actor, entry_id=entry_id)
    connection.send_result(msg["id"], {"saved": True, "ui": _redact_ui_data(saved)})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_mode_config",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_mode_config(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    connection.send_result(msg["id"], (await async_load_ui_data(hass, entry_id)).get("modes", {}))


@websocket_api.websocket_command({
    vol.Required("type"): "argus/save_mode_config",
    vol.Required("mode"): vol.In(["disarmed", "home", "away", "night"]),
    vol.Optional("entity_id", default=""): str,
    vol.Optional("entry_id"): str,
    vol.Required("config"): dict,
})
@websocket_api.async_response
async def ws_argus_save_mode_config(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    data = await async_load_ui_data(hass, entry_id)
    modes = copy.deepcopy(data.get("modes", {}))
    mode, config, entity_id = msg["mode"], copy.deepcopy(msg["config"]), msg["entity_id"]
    # v2.0.29: external panels are outputs of the Sirens section.  Preserve
    # old saves while normalising the canonical field on their next save.
    legacy_panels = config.pop("sync_panels", [])
    configured_panels = config.get("external_panels", [])
    if not isinstance(configured_panels, list):
        configured_panels = []
    if isinstance(legacy_panels, list):
        configured_panels.extend(panel for panel in legacy_panels if panel not in configured_panels)
    legacy_alarm_sirens = [item for item in config.get("sirens", []) if str(item).startswith("alarm_control_panel.")]
    config["sirens"] = [item for item in config.get("sirens", []) if not str(item).startswith("alarm_control_panel.")]
    config["external_panels"] = list(dict.fromkeys(configured_panels + legacy_alarm_sirens))
    if entity_id:
        modes.setdefault("__by_entity__", {}).setdefault(entity_id, {})[mode] = config
    else:
        modes[mode] = config
    await async_save_ui_data(hass, {"modes": modes}, entry_id)
    async_dispatcher_send(hass, SIGNAL_CONFIG_UPDATED, entry_id)
    connection.send_result(msg["id"], {"success": True, "modes": modes})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_audit_log",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_audit_log(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    connection.send_result(msg["id"], {"log": await async_get_audit_log(hass, entry_id)})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_stats",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_stats(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    log = await async_get_audit_log(hass, entry_id)
    cutoff = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=30)
    stats = {"total_events": len(log), "triggers_30d": 0, "armings_30d": 0, "top_sensors": {}}
    for event in log:
        try:
            timestamp = datetime.datetime.fromisoformat(str(event.get("ts", "")).replace("Z", "+00:00"))
        except ValueError:
            continue
        if timestamp < cutoff:
            continue
        action = str(event.get("action", ""))
        if "trigger" in action:
            stats["triggers_30d"] += 1
        elif "armed" in action:
            stats["armings_30d"] += 1
        sensor = event.get("metadata", {}).get("sensor_entity_id")
        if sensor:
            stats["top_sensors"][sensor] = stats["top_sensors"].get(sensor, 0) + 1
    connection.send_result(msg["id"], stats)


@websocket_api.websocket_command({
    vol.Required("type"): "argus/clear_audit_log",
    vol.Optional("entry_id"): str,
    vol.Optional("user_name"): str,
})
@websocket_api.async_response
async def ws_argus_clear_audit_log(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
        actor = msg.get("user_name") or profile.get("name") or getattr(connection.user, "name", "Administrador")
    except ArgusAuthError:
        if connection.user and connection.user.is_admin:
            actor = msg.get("user_name") or getattr(connection.user, "name", "Administrador")
        else:
            connection.send_error(msg["id"], "unauthorized", "Requires Argus administrator privileges")
            return
    await async_clear_audit_log(hass, actor=actor, entry_id=entry_id)
    connection.send_result(msg["id"], {"cleared": True, "user": actor})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/validate_master_pin",
    vol.Required("pin"): str,
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_validate_master_pin(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    entry = _entry_by_id(hass, entry_id)
    if not entry:
        connection.send_error(msg["id"], "not_found", "Argus config entry not found")
        return
    ha_user_id, _ = _get_ha_actor(connection)
    key = f"validate:{ha_user_id}:{entry_id}"
    limiter = _limiter(hass, entry_id)
    if limiter.is_blocked(key):
        connection.send_error(msg["id"], "rate_limited", "Too many failed attempts; try again later")
        return
    current = entry.options.get("code") or entry.data.get("code") or ""
    if not current:
        connection.send_result(msg["id"], {"valid": True, "pin_configured": False})
        return
    if not verify_pin(msg["pin"], current):
        limiter.record_failure(key)
        connection.send_error(msg["id"], "invalid_pin", "Incorrect PIN")
        return
    limiter.reset(key)
    connection.send_result(msg["id"], {"valid": True, "pin_configured": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/export_config",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_export_config(hass, connection, msg) -> None:
    """Return a complete backup payload to an authenticated Argus admin.

    The panel encrypts this payload before downloading it. Credential hashes
    are included here, but never in dashboard responses, so a backup can
    restore both profile access and the master PIN on a fresh installation.
    """
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    config = copy.deepcopy(await async_load_ui_data(hass, entry_id))
    entry = hass.config_entries.async_get_entry(entry_id)
    master_pin_hash = ""
    if entry:
        master_pin_hash = entry.options.get("code") or entry.data.get("code") or ""
    config["_argus_backup"] = {"version": 1, "master_pin_hash": master_pin_hash}
    connection.send_result(msg["id"], {"config": config})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/restore_config",
    vol.Optional("entry_id"): str,
    vol.Required("config"): dict,
})
@websocket_api.async_response
async def ws_argus_restore_config(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    current = await async_load_ui_data(hass, entry_id)
    is_first_run = current.get("first_run", True)
    restored_from_first_run = False
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
        actor = profile.get("name", "Unknown")
    except ArgusAuthError as err:
        # A fresh installation has no Argus profile or session yet. Its first
        # restore is authorized by HA admin rights only; established installs
        # still require an Argus administrator session.
        if not is_first_run:
            connection.send_error(msg["id"], err.code, err.message)
            return
        try:
            _require_ha_admin(connection)
        except ArgusAuthError as ha_err:
            connection.send_error(msg["id"], ha_err.code, ha_err.message)
            return
        _, actor = _get_ha_actor(connection)
        restored_from_first_run = True

    backup_meta = msg["config"].get("_argus_backup", {})
    master_pin_hash = backup_meta.get("master_pin_hash", "") if isinstance(backup_meta, dict) else ""
    try:
        restored = await async_restore_ui_data(hass, msg["config"], actor=actor, entry_id=entry_id)
        if master_pin_hash and not needs_rehash(master_pin_hash):
            entry = hass.config_entries.async_get_entry(entry_id)
            if entry:
                options = dict(entry.options)
                options["code"] = master_pin_hash
                hass.config_entries.async_update_entry(entry, options=options)

        ha_user_id, actor_name = _get_ha_actor(connection)
        users = copy.deepcopy(restored.get("users", []))
        
        if "theme" in msg.get("config", {}):
            theme_data = msg["config"]["theme"]
            for user in users:
                if user.get("ha_user_id") == ha_user_id:
                    user.setdefault("theme", {})
                    user["theme"]["background_mode"] = theme_data.get("background_mode", "default")
                    user["theme"]["background_file"] = theme_data.get("background_file", "")
                    break
            # Guardar enseguida
            restored = await async_save_ui_data(hass, {"users": users}, entry_id)

        if restored_from_first_run:
            restored_profile = next(
                (user for user in users if user.get("ha_user_id") == ha_user_id and user.get("enabled", True)),
                None,
            )
            if restored_profile is None:
                restored_profile = {
                    "id": str(uuid.uuid4()), "name": actor_name, "ha_user_id": ha_user_id,
                    "role": "admin", "enabled": True,
                    "permissions": {"view_status": True, "view_history": True, "arm": True, "disarm": True, "sos": True},
                }
                users.append(restored_profile)
            else:
                restored_profile["role"] = "admin"
                restored_profile["permissions"] = {"view_status": True, "view_history": True, "arm": True, "disarm": True, "sos": True}
            restored = await async_save_ui_data(hass, {"first_run": False, "users": users}, entry_id)
            async_get_session_manager(hass).create_session(
                ha_user_id, entry_id, restored_profile["id"], "first_run_restore"
            )
    except ValueError as err:
        connection.send_error(msg["id"], "invalid_backup", str(err))
        return
    async_dispatcher_send(hass, SIGNAL_CONFIG_UPDATED, entry_id)
    connection.send_result(msg["id"], {"success": True, "ui": _redact_ui_data(restored)})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/save_advanced_config",
    vol.Optional("entry_id"): str,
    vol.Required("config"): dict,
})
@websocket_api.async_response
async def ws_argus_save_advanced_config(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    config = copy.deepcopy(msg["config"])
    guest = config.get("guest_code")
    if guest and not str(guest).startswith(("scrypt:", "pbkdf2_sha256:")):
        if not validate_pin(str(guest)):
            connection.send_error(msg["id"], "invalid_pin", "Guest PIN does not satisfy the security policy")
            return
        config["guest_code"] = hash_pin(str(guest))

    duress = config.get("duress_pin")
    if duress and not str(duress).startswith(("scrypt:", "pbkdf2_sha256:")):
        if not validate_pin(str(duress)):
            connection.send_error(msg["id"], "invalid_pin", "Duress PIN does not satisfy the security policy")
            return
        config["duress_pin"] = hash_pin(str(duress))

    await async_save_ui_data(hass, {"advanced": config}, entry_id)
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_advanced_config",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_advanced_config(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    advanced = copy.deepcopy((await async_load_ui_data(hass, entry_id)).get("advanced", {}))
    advanced["guest_code_configured"] = bool(advanced.get("guest_code"))
    advanced.pop("guest_code", None)
    advanced["duress_pin_configured"] = bool(advanced.get("duress_pin"))
    advanced.pop("duress_pin", None)
    connection.send_result(msg["id"], advanced)


@websocket_api.websocket_command({
    vol.Required("type"): "argus/save_automations",
    vol.Optional("entry_id"): str,
    vol.Required("automations"): list,
})
@websocket_api.async_response
async def ws_argus_save_automations(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    await async_save_ui_data(hass, {"automations": copy.deepcopy(msg["automations"])}, entry_id)
    async_dispatcher_send(hass, SIGNAL_CONFIG_UPDATED, entry_id)
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_automations",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_automations(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    connection.send_result(msg["id"], (await async_load_ui_data(hass, entry_id)).get("automations", []))


@websocket_api.websocket_command({vol.Required("type"): "argus/get_zones", vol.Optional("entry_id"): str})
@websocket_api.async_response
async def ws_argus_get_zones(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    device_reg = dr.async_get(hass)
    devices = [{"device_id": device.id, "name": device.name or device.id, "area_id": device.area_id}
               for device in device_reg.devices]
    connection.send_result(msg["id"], {
        "zones": (await async_load_ui_data(hass, entry_id)).get("zones", []),
        "available_entities": _serialize_available_entities(hass),
        "available_devices": devices,
    })


@websocket_api.websocket_command({
    vol.Required("type"): "argus/save_zones", vol.Optional("entry_id"): str,
    vol.Required("zones"): list,
})
@websocket_api.async_response
async def ws_argus_save_zones(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
        from .zones import project_zone_modes, sanitize_zones
        entity_ids = {item["entity_id"] for item in _serialize_available_entities(hass)}
        device_ids = {device.id for device in dr.async_get(hass).devices}
        zones = sanitize_zones(msg["zones"], entity_ids, device_ids)
        current = await async_load_ui_data(hass, entry_id)
        modes = project_zone_modes(current.get("modes", {}), current.get("zones", []), zones)
        saved = await async_save_ui_data(hass, {"zones": zones, "zones_initialized": True, "modes": modes}, entry_id)
    except (ArgusAuthError, ValueError) as err:
        if isinstance(err, ArgusAuthError):
            connection.send_error(msg["id"], err.code, err.message)
        else:
            connection.send_error(msg["id"], "invalid_zones", str(err))
        return
    except Exception:
        _LOGGER.exception("Unexpected failure saving Argus zones for entry %s", entry_id)
        connection.send_error(msg["id"], "zone_save_failed", "No se pudieron guardar las zonas. Revisa el registro de Argus.")
        return
    async_dispatcher_send(hass, SIGNAL_CONFIG_UPDATED, entry_id)
    await async_append_audit_log(hass, "zones_updated", user=profile.get("name", "Unknown"), entry_id=entry_id)
    connection.send_result(msg["id"], {"success": True, "zones": saved.get("zones", []), "modes": saved.get("modes", {})})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_voice_config",
    vol.Optional("entry_id"): str,
    vol.Optional("mode"): str,
})
@websocket_api.async_response
async def ws_argus_get_voice_config(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    entry = _entry_by_id(hass, entry_id)
    if entry is None:
        connection.send_error(msg["id"], "not_found", "Argus config entry not found")
        return
    ui_data = await async_load_ui_data(hass, entry_id)
    ui_values = ui_data.get("arming_voice", {})
    yaml_values = hass.data.get(DOMAIN, {}).get("arming_voice_yaml", {})
    # Import prior Options/YAML settings into the Argus editor on first use.
    # Presence is checked by key so an intentionally empty custom message is
    # preserved instead of being replaced by an older value.
    values, missing_values, imported_settings = resolve_voice_settings(
        _VOICE_FIELDS, entry.data, entry.options, yaml_values, ui_values
    )
    if missing_values:
        ui_data = await async_save_ui_data(hass, {"arming_voice": values}, entry_id)
        ui_values = ui_data.get("arming_voice", values)
        hass.data.setdefault(DOMAIN, {}).setdefault("arming_voice_ui", {})[entry_id] = ui_values
        values, _, imported_settings = resolve_voice_settings(
            _VOICE_FIELDS, entry.data, entry.options, yaml_values, ui_values
        )
    language = await _get_language(hass, entry)
    default_message_keys = {
        CONF_ARMING_VOICE_MESSAGE_START: "msg_start",
        CONF_ARMING_VOICE_MESSAGE_REMAINING: "msg_remaining",
        CONF_ARMING_VOICE_MESSAGE_LAST: "msg_last",
        CONF_ARMING_VOICE_MESSAGE_COMPLETE: "msg_complete",
        CONF_ARMING_VOICE_MESSAGE_ARMED: "msg_armed",
        CONF_ARMING_VOICE_MESSAGE_CANCELLED: "msg_cancelled",
        CONF_ARMING_VOICE_MESSAGE_TRIGGERED: "msg_triggered",
        CONF_ARMING_VOICE_MESSAGE_ADDITIONAL_TRIGGERED: "msg_additional",
        CONF_ARMING_VOICE_MESSAGE_ALARM_SENSOR_CLOSED: "msg_alarm_sensor_closed",
    }
    default_messages = {field: translate(language, key) for field, key in default_message_keys.items()}
    mode = msg.get("mode", "")
    assigned_zones = []
    if mode in {"disarmed", "home", "away", "night"}:
        entity_registry = er.async_get(hass)
        for zone in ui_data.get("zones", []):
            zone_modes = zone.get("modes", []) if isinstance(zone, dict) else []
            if not isinstance(zone_modes, list) or not isinstance(zone, dict) or zone.get("enabled", True) is False or mode not in zone_modes:
                continue
            sensors = []
            for entity_id in zone.get("entity_ids", []):
                state = hass.states.get(entity_id)
                registry_entry = entity_registry.async_get(entity_id)
                name = (registry_entry.name if registry_entry else None) or (state.attributes.get("friendly_name") if state else None) or entity_id
                sensors.append({
                    "entity_id": entity_id,
                    "name": str(name),
                    "state": state.state if state else "unknown",
                })
            assigned_zones.append({
                "number": zone.get("number"),
                "area": str(zone.get("area") or ""),
                "sensors": sensors,
            })
    connection.send_result(msg["id"], {
        "values": values,
        # YAML is now a migration source only; Argus owns subsequent edits.
        "yaml_keys": [],
        "imported_existing_settings": imported_settings,
        "default_messages": default_messages,
        "mode": mode,
        "assigned_zones": assigned_zones,
        "tts_entities": [{"entity_id": state.entity_id, "name": state.name} for state in hass.states.async_all("tts")],
        "media_players": _media_player_entities(hass),
    })


@websocket_api.websocket_command({
    vol.Required("type"): "argus/save_voice_config",
    vol.Optional("entry_id"): str,
    vol.Required("config"): dict,
})
@websocket_api.async_response
async def ws_argus_save_voice_config(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    entry = _entry_by_id(hass, entry_id)
    if entry is None:
        connection.send_error(msg["id"], "not_found", "Argus config entry not found")
        return
    config = msg["config"]
    if set(config) - set(_VOICE_FIELDS):
        connection.send_error(msg["id"], "invalid_voice_config", "Unknown voice setting")
        return
    ui_data = await async_load_ui_data(hass, entry_id)
    existing, _, _ = resolve_voice_settings(
        _VOICE_FIELDS,
        entry.data,
        entry.options,
        hass.data.get(DOMAIN, {}).get("arming_voice_yaml", {}),
        ui_data.get("arming_voice", {}),
    )
    tts = config.get(CONF_ARMING_VOICE_TTS, existing.get(CONF_ARMING_VOICE_TTS, ""))
    players = config.get(CONF_ARMING_VOICE_PLAYERS, existing.get(CONF_ARMING_VOICE_PLAYERS, []))
    valid_tts = {state.entity_id for state in hass.states.async_all("tts")}
    valid_players = {player["entity_id"] for player in _media_player_entities(hass)}
    previous_value = existing.get(CONF_ARMING_VOICE_PLAYERS, [])
    previous_players = set(previous_value if isinstance(previous_value, list) else [])
    if not isinstance(tts, str) or (tts and tts not in valid_tts):
        connection.send_error(msg["id"], "invalid_tts", "Select an available TTS entity")
        return
    if not isinstance(players, list) or len(players) > 5 or any(
        not isinstance(player, str) or player not in valid_players | previous_players
        for player in players
    ):
        connection.send_error(msg["id"], "invalid_players", "Select up to five available media players")
        return
    if CONF_ARMING_VOICE_ENABLED in config and not isinstance(config[CONF_ARMING_VOICE_ENABLED], bool):
        connection.send_error(msg["id"], "invalid_voice_config", "Voice enabled must be boolean")
        return
    for key in _VOICE_FIELDS[3:]:
        if key in config and (not isinstance(config[key], str) or len(config[key]) > 500):
            connection.send_error(msg["id"], "invalid_voice_config", "Voice message must be at most 500 characters")
            return
    voice = {key: value for key, value in existing.items() if value is not None}
    voice.update(config)
    saved = await async_save_ui_data(hass, {"arming_voice": voice}, entry_id)
    hass.data.setdefault(DOMAIN, {}).setdefault("arming_voice_ui", {})[entry_id] = saved.get("arming_voice", voice)
    async_dispatcher_send(hass, SIGNAL_CONFIG_UPDATED, entry_id)
    await async_append_audit_log(hass, "voice_config_updated", user=profile.get("name", "Unknown"), entry_id=entry_id)
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({vol.Required("type"): "argus/get_media_players"})
@websocket_api.async_response
async def ws_argus_get_media_players(hass, connection, msg) -> None:
    try:
        _require_ha_admin(connection)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    connection.send_result(msg["id"], _media_player_entities(hass))


@websocket_api.websocket_command({
    vol.Required("type"): "argus/update_master_pin",
    vol.Required("entry_id"): str,
    vol.Required("pin"): str,
    vol.Optional("current_pin", default=""): str,
})
@websocket_api.async_response
async def ws_argus_update_master_pin(hass, connection, msg) -> None:
    try:
        profile, _ = await _require_argus_admin(hass, connection, msg["entry_id"])
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    actor = profile.get("name", "Unknown")

    entry = _entry_by_id(hass, msg["entry_id"])
    if not entry:
        connection.send_error(msg["id"], "not_found", "Argus config entry not found")
        return
    new_pin = msg["pin"]
    if new_pin and not validate_pin(new_pin):
        connection.send_error(msg["id"], "invalid_pin", "PIN must be 4-12 non-trivial digits")
        return

    key = f"{profile['id']}:{entry.entry_id}"
    limiter = _limiter(hass, entry.entry_id)
    if limiter.is_blocked(key):
        connection.send_error(msg["id"], "rate_limited", "Too many failed attempts; try again later")
        return

    current = entry.options.get("code") or entry.data.get("code") or ""
    if current and not verify_pin(msg.get("current_pin", ""), current):
        blocked = limiter.record_failure(key)
        await async_append_audit_log(
            hass,
            "master_pin_rejected",
            user=actor,
            severity="critical" if blocked else "warning",
            metadata={"entry_id": entry.entry_id, "rate_limited": blocked},
            entry_id=entry.entry_id,
        )
        connection.send_error(msg["id"], "invalid_pin", "Current PIN is incorrect")
        return

    limiter.reset(key)
    options = dict(entry.options)
    options["code"] = hash_pin(new_pin) if new_pin else ""
    hass.config_entries.async_update_entry(entry, options=options)
    await async_append_audit_log(
        hass,
        "master_pin_updated",
        user=actor,
        severity="warning",
        metadata={"entry_id": entry.entry_id, "legacy_migrated": needs_rehash(current)},
        entry_id=entry.entry_id,
    )
    await hass.config_entries.async_reload(entry.entry_id)
    connection.send_result(msg["id"], {"success": True})



@websocket_api.websocket_command({
    vol.Required("type"): "argus/verify_master_pin_for_screen_unlock",
    vol.Required("entry_id"): str,
    vol.Required("pin"): str,
})
@websocket_api.async_response
async def ws_argus_verify_master_pin_for_screen_unlock(hass, connection, msg) -> None:
    entry = _entry_by_id(hass, msg["entry_id"])
    if not entry:
        connection.send_error(msg["id"], "not_found", "Argus config entry not found")
        return

    ha_user_id, actor = _get_ha_actor(connection)

    key = f"kiosk:{ha_user_id}:{entry.entry_id}"
    limiter = _limiter(hass, entry.entry_id)
    if limiter.is_blocked(key):
        connection.send_error(msg["id"], "rate_limited", "Too many failed attempts; try again later")
        return

    current = entry.options.get("code") or entry.data.get("code") or ""
    if not current:
        connection.send_error(msg["id"], "no_master_pin_configured", "Master PIN not configured")
        return

    if not verify_pin(msg["pin"], current):
        blocked = limiter.record_failure(key)
        await async_append_audit_log(
            hass,
            "master_pin_rejected",
            user=actor,
            severity="critical" if blocked else "warning",
            metadata={"entry_id": entry.entry_id, "rate_limited": blocked, "reason": "kiosk_unlock"},
            entry_id=entry.entry_id,
        )
        connection.send_error(msg["id"], "invalid_pin", "Incorrect PIN")
        return

    limiter.reset(key)
    await async_append_audit_log(
        hass,
        "fullscreen_unlocked",
        user=actor,
        severity="info",
        metadata={"entry_id": entry.entry_id},
        entry_id=entry.entry_id,
    )
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/login_bootstrap",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_login_bootstrap(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))

    ha_user_id, _ = _get_ha_actor(connection)
    if entry_id is None:
        # The panel is registered before a config entry exists. Avoid falling
        # back to legacy global storage when there is no alarm instance.
        connection.send_result(msg["id"], {
            "configuration_missing": True,
            "first_run": False,
            "legacy_claim_needed": False,
            "users": [],
            "has_active_session": False,
            "active_argus_user_id": None,
            "ha_user_id": ha_user_id,
            "background_mode": "none",
            "background_images": [],
            "weather_source": None,
            "temperature_source": None,
            "language": None,
        })
        return

    sm = async_get_session_manager(hass)
    session = sm.get_session(ha_user_id, entry_id)

    # Atomically sync HA accounts to Argus profiles (idempotent, skips first_run)
    await async_sync_ha_profiles(hass, entry_id)

    # Re-load after potential sync changes
    ui_data = await async_load_ui_data(hass, entry_id)

    # Map HA person entity attributes to ha_user_ids
    person_map: dict[str, dict] = {}
    for state in hass.states.async_all("person"):
        p_user_id = state.attributes.get("user_id")
        if p_user_id:
            person_map[p_user_id] = {
                "picture": state.attributes.get("entity_picture"),
                "state": state.state,
            }

    public_users = []
    for u in ui_data.get("users", []):
        if u.get("enabled", True):
            u_ha_id = u.get("ha_user_id")
            p_info = person_map.get(u_ha_id, {}) if u_ha_id else {}
            picture = u.get("picture") or p_info.get("picture")
            is_current = (u_ha_id == ha_user_id) if u_ha_id else False
            p_state = p_info.get("state")
            # A person is present only when HA reports "home". The current
            # authenticated WebSocket user is also active by definition.
            is_online = is_current or p_state == "home"

            public_users.append({
                "id": u["id"],
                "name": u["name"],
                "role": u["role"],
                "shared_kiosk_profile": u.get("shared_kiosk_profile", False),
                "access_pin_configured": bool(u.get("access_pin_hash")),
                "is_own_profile": is_current,
                "picture": picture,
                "online": is_online,
            })

    has_real_admin = False
    for u in ui_data.get("users", []):
        if u.get("role") == "admin" and u.get("enabled", True) and u.get("ha_user_id"):
            u_obj = await hass.auth.async_get_user(u["ha_user_id"])
            if u_obj and u_obj.is_admin:
                has_real_admin = True
                break

    user_theme = {"background_mode": "default", "background_file": ""}
    for u in ui_data.get("users", []):
        if u.get("ha_user_id") == ha_user_id:
            user_theme = u.get("theme", user_theme)
            break

    connection.send_result(msg["id"], {
        "first_run": ui_data.get("first_run", False),
        "legacy_claim_needed": not ui_data.get("first_run", False) and not has_real_admin,
        "users": public_users,
        "has_active_session": bool(session),
        "active_argus_user_id": session.argus_user_id if session else None,
        "ha_user_id": ha_user_id,
        "background_mode": ui_data.get("background_mode"),
        "background_images": ui_data.get("background_images"),
        "panel_bg_file": ui_data.get("panel_bg_file"),
        "panel_bg_sound": ui_data.get("panel_bg_sound"),
        "hub_bg_mode": ui_data.get("hub_bg_mode"),
        "hub_bg_file": ui_data.get("hub_bg_file"),
        "hub_bg_sound": ui_data.get("hub_bg_sound"),
        "weather_source": ui_data.get("weather_source"),
        "temperature_source": ui_data.get("temperature_source"),
        "language": ui_data.get("language"),
        "user_theme": user_theme,
    })


@websocket_api.websocket_command({
    vol.Required("type"): "argus/complete_first_run",
    vol.Optional("entry_id"): str,
    vol.Required("admin_name"): str,
    vol.Optional("master_pin"): str,
    vol.Optional("access_pin"): str,
})
@websocket_api.async_response
async def ws_argus_complete_first_run(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        _require_ha_admin(connection)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    ha_user_id, actor_name = _get_ha_actor(connection)
    ui_data = await async_load_ui_data(hass, entry_id)

    if not ui_data.get("first_run", True):
        connection.send_error(msg["id"], "already_configured", "Argus is already configured")
        return

    argus_user_id = str(uuid.uuid4())
    new_user = {
        "id": argus_user_id,
        "name": msg["admin_name"],
        "ha_user_id": ha_user_id,
        "role": "admin",
        "enabled": True,
        "permissions": {"view_status": True, "view_history": True, "arm": True, "disarm": True, "sos": True},
    }

    if msg.get("access_pin"):
        if not validate_pin(str(msg["access_pin"])):
            connection.send_error(msg["id"], "invalid_pin", "Access PIN does not satisfy the security policy")
            return
        new_user["access_pin_hash"] = hash_pin(str(msg["access_pin"]))

    updates = {
        "first_run": False,
        "users": ui_data.get("users", []) + [new_user]
    }

    if msg.get("master_pin"):
        if not validate_pin(str(msg["master_pin"])):
            connection.send_error(msg["id"], "invalid_pin", "Master PIN does not satisfy the security policy")
            return
        entry = hass.config_entries.async_get_entry(entry_id)
        if entry:
            new_options = dict(entry.options)
            new_options["code"] = hash_pin(str(msg["master_pin"]))
            hass.config_entries.async_update_entry(entry, options=new_options)

    await async_save_ui_data(hass, updates, entry_id)

    sm = async_get_session_manager(hass)
    sm.create_session(ha_user_id, entry_id, argus_user_id, "first_run")

    await async_append_audit_log(
        hass, "first_run_completed", f"Argus initialized by {actor_name}", user=actor_name, entry_id=entry_id
    )
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/claim_legacy_administration",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_claim_legacy_administration(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        _require_ha_admin(connection)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    ha_user_id, actor_name = _get_ha_actor(connection)
    ui_data = await async_load_ui_data(hass, entry_id)

    if ui_data.get("first_run", False):
        connection.send_error(msg["id"], "invalid_state", "Use complete_first_run for new installations")
        return

    # Check if there is already a real admin
    has_real_admin = False
    for u in ui_data.get("users", []):
        if u.get("role") == "admin" and u.get("enabled", True) and u.get("ha_user_id"):
            u_obj = await hass.auth.async_get_user(u["ha_user_id"])
            if u_obj and u_obj.is_admin:
                has_real_admin = True
                break

    if has_real_admin:
        connection.send_error(msg["id"], "already_claimed", "Argus already has a valid HA administrator linked")
        return

    # Either link the first admin we find or create one
    admin_user = None
    users = ui_data.get("users", [])
    for u in users:
        if u.get("role") == "admin":
            u["ha_user_id"] = ha_user_id
            admin_user = u
            break

    if not admin_user:
        argus_user_id = str(uuid.uuid4())
        admin_user = {
            "id": argus_user_id,
            "name": actor_name,
            "ha_user_id": ha_user_id,
            "role": "admin",
            "enabled": True,
            "permissions": {"view_status": True, "view_history": True, "arm": True, "disarm": True, "sos": True},
        }
        users.append(admin_user)

    await async_save_ui_data(hass, {"users": users}, entry_id)

    sm = async_get_session_manager(hass)
    sm.create_session(ha_user_id, entry_id, admin_user["id"], "legacy_claim")

    await async_append_audit_log(
        hass, "legacy_admin_claimed", "Security update: Admin profile claimed", user=actor_name, severity="critical", entry_id=entry_id
    )
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/verify_access_pin",
    vol.Optional("entry_id"): str,
    vol.Required("argus_user_id"): str,
    vol.Required("pin"): str,
})
@websocket_api.async_response
async def ws_argus_verify_access_pin(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    ha_user_id, actor_name = _get_ha_actor(connection)

    argus_user_id = msg["argus_user_id"]
    ui_data = await async_load_ui_data(hass, entry_id)

    target_user = None
    for u in ui_data.get("users", []):
        if u.get("id") == argus_user_id:
            target_user = u
            break

    if not target_user or not target_user.get("enabled", True):
        connection.send_error(msg["id"], "invalid_user", "User not found or disabled")
        return

    if not target_user.get("access_pin_hash"):
        connection.send_error(msg["id"], "invalid_request", "User does not have an access PIN configured")
        return

    limiter_key = f"{ha_user_id}:{entry_id}:{argus_user_id}"
    limiter = _limiter(hass, entry_id)
    if limiter.is_blocked(limiter_key):
        connection.send_error(msg["id"], "rate_limited", "Too many failed attempts; try again later")
        return

    if not verify_pin(msg["pin"], target_user["access_pin_hash"]):
        blocked = limiter.record_failure(limiter_key)
        await async_append_audit_log(
            hass, "access_pin_rejected", f"Failed login for {target_user['name']}", user=actor_name,
            severity="critical" if blocked else "warning", metadata={"rate_limited": blocked}, entry_id=entry_id
        )
        connection.send_error(msg["id"], "invalid_pin", "Incorrect PIN")
        return

    limiter.reset(limiter_key)
    sm = async_get_session_manager(hass)
    sm.create_session(ha_user_id, entry_id, argus_user_id, "access_pin")

    await async_append_audit_log(
        hass, "user_logged_in", f"{target_user['name']} logged in", user=target_user["name"], entry_id=entry_id
    )
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/select_profile",
    vol.Optional("entry_id"): str,
    vol.Required("argus_user_id"): str,
})
@websocket_api.async_response
async def ws_argus_select_profile(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    ha_user_id, actor_name = _get_ha_actor(connection)

    argus_user_id = msg["argus_user_id"]
    ui_data = await async_load_ui_data(hass, entry_id)

    target_user = None
    for u in ui_data.get("users", []):
        if u.get("id") == argus_user_id:
            target_user = u
            break

    if not target_user or not target_user.get("enabled", True):
        connection.send_error(msg["id"], "invalid_user", "User not found or disabled")
        return

    if target_user.get("access_pin_hash"):
        connection.send_error(msg["id"], "pin_required", "This profile requires a PIN")
        return

    # Security check: Without PIN, ha_user_id must match OR shared_kiosk_profile must be true
    is_shared = target_user.get("shared_kiosk_profile", False)
    if target_user.get("ha_user_id") != ha_user_id and not is_shared:
        await async_append_audit_log(
            hass, "profile_select_rejected", f"Unauthorized attempt to select {target_user['name']} without PIN",
            user=actor_name, severity="critical", entry_id=entry_id
        )
        connection.send_error(msg["id"], "unauthorized", "Cannot select this profile without authorization")
        return

    sm = async_get_session_manager(hass)
    sm.create_session(ha_user_id, entry_id, argus_user_id, "direct_select")

    await async_append_audit_log(
        hass, "user_logged_in", f"{target_user['name']} selected profile", user=target_user["name"], entry_id=entry_id
    )
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/logout_profile",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_logout_profile(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    ha_user_id, _ = _get_ha_actor(connection)

    sm = async_get_session_manager(hass)
    session = sm.get_session(ha_user_id, entry_id)
    if session:
        sm.invalidate_session(ha_user_id, entry_id)

    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/perform_alarm_action",
    vol.Optional("entry_id"): str,
    vol.Required("action"): vol.In(["arm_home", "arm_away", "arm_night", "disarm", "sos", "stop_sos"]),
    vol.Optional("code"): str,
})
@websocket_api.async_response
async def ws_argus_perform_alarm_action(hass, connection, msg) -> None:
    action_started = time.perf_counter()
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    action = msg["action"]

    # 1. Require Session
    try:
        profile, ha_user_id = await _require_argus_session(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    # 2. Check Permission
    req_perm = "arm" if action.startswith("arm_") else "disarm" if action == "disarm" else "sos"
    try:
        await _require_permission(hass, connection, entry_id, req_perm)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    # 3. Perform action on the HA entity
    entity_id = _resolve_alarm_entity_id(hass, entry_id)
    if not entity_id:
        connection.send_error(msg["id"], "not_found", "Alarm entity not found")
        return

    service_data = {"entity_id": entity_id}
    if msg.get("code"):
        service_data["code"] = msg["code"]

    service = f"alarm_{action}" if action != "sos" else "alarm_trigger"

    from homeassistant.core import Context
    ctx = Context(user_id=ha_user_id)

    try:
        if action == "stop_sos":
            from .const import DOMAIN, DATA_PANELS

            panel = hass.data.get(DOMAIN, {}).get(DATA_PANELS, {}).get(entry_id)
            if panel is None:
                connection.send_error(msg["id"], "not_found", "Alarm entity not found")
                return
            await panel.async_stop_panic()
        else:
            await hass.services.async_call(
                "alarm_control_panel", service, service_data, blocking=True, context=ctx
            )
    except Exception as err:
        connection.send_error(msg["id"], "service_failed", str(err))
        return

    _LOGGER.info(
        "Argus panel action %s accepted in %.1f ms",
        action, (time.perf_counter() - action_started) * 1000,
    )

    async def append_action_audit() -> None:
        try:
            await async_append_audit_log(
                hass, f"action_{action}",
                f"Panel action {action} triggered by {profile.get('name')}",
                user=profile.get("name"), entry_id=entry_id,
            )
        except Exception:  # noqa: BLE001
            _LOGGER.exception("Argus: failed to record panel action %s", action)

    hass.async_create_task(append_action_audit())
    alarm_state = hass.states.get(entity_id)
    connection.send_result(msg["id"], {
        "success": True,
        "state": alarm_state.state if alarm_state else None,
    })


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_ha_users",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_ha_users(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        _require_ha_admin(connection)
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    raw_users = await hass.auth.async_get_users()
    filtered = [
        u for u in raw_users
        if not getattr(u, "system_generated", False) and getattr(u, "is_active", True)
    ]
    name_counts = {}
    for u in filtered:
        name_counts[u.name] = name_counts.get(u.name, 0) + 1

    users = []
    for u in filtered:
        display_name = u.name
        if name_counts.get(u.name, 0) > 1 and len(u.id) >= 6:
            display_name = f"{u.name} (…{u.id[-6:]})"
        users.append({"id": u.id, "name": display_name, "is_admin": u.is_admin})

    connection.send_result(msg["id"], {"ha_users": users})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_ha_persons",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_ha_persons(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        _require_ha_admin(connection)
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    persons = []
    for state in hass.states.async_all("person"):
        persons.append({
            "entity_id": state.entity_id,
            "name": state.attributes.get("friendly_name") or state.entity_id,
            "user_id": state.attributes.get("user_id"),
        })
    connection.send_result(msg["id"], {"ha_persons": persons})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/save_user_access_pin",
    vol.Optional("entry_id"): str,
    vol.Required("argus_user_id"): str,
    vol.Required("pin"): str,
})
@websocket_api.async_response
async def ws_argus_save_user_access_pin(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, ha_user_id = await _require_argus_session(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    is_admin = profile.get("role") == "admin"
    is_self = profile.get("id") == msg["argus_user_id"]
    can_change = is_admin
    if not can_change:
        connection.send_error(msg["id"], "unauthorized", "Permission denied to change PIN")
        return

    ui_data = await async_load_ui_data(hass, entry_id)
    users = ui_data.get("users", [])

    target_idx = -1
    for i, u in enumerate(users):
        if u.get("id") == msg["argus_user_id"]:
            target_idx = i
            break

    if target_idx == -1:
        connection.send_error(msg["id"], "not_found", "User not found")
        return

    new_pin = msg["pin"]
    if new_pin and not validate_pin(new_pin):
        connection.send_error(msg["id"], "invalid_pin", "PIN does not satisfy the security policy")
        return

    users[target_idx]["access_pin_hash"] = hash_pin(new_pin) if new_pin else ""
    await async_save_ui_data(hass, {"users": users}, entry_id)

    # Invalidate existing sessions for this user so they must log in again
    sm = async_get_session_manager(hass)
    sm.invalidate_all_for_argus_user(entry_id, msg["argus_user_id"])

    await async_append_audit_log(
        hass, "access_pin_updated", f"Access PIN updated for {users[target_idx]['name']} by {profile['name']}",
        user=profile["name"], severity="warning", entry_id=entry_id
    )
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/sync_presence_rules",
    vol.Optional("entry_id"): str,
    vol.Required("rules"): list,
})
@websocket_api.async_response
async def ws_argus_sync_presence_rules(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    # Will be implemented in Phase 4
    await async_save_ui_data(hass, {"presence_rules": msg["rules"]}, entry_id)
    async_dispatcher_send(hass, SIGNAL_CONFIG_UPDATED, entry_id)
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_profile_theme",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_profile_theme(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_session(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    
    theme = profile.get("theme", {"background_mode": "default", "background_file": ""})
    connection.send_result(msg["id"], {"theme": theme})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/save_profile_theme",
    vol.Required("theme"): dict,
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_save_profile_theme(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_session(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    
    ui_data = await async_load_ui_data(hass, entry_id)
    users = ui_data.get("users", [])
    
    theme = msg["theme"]
    for u in users:
        if u.get("id") == profile.get("id"):
            u["theme"] = theme
            u["background_mode"] = theme.get("background_mode", "weather")
            u["background_images"] = theme.get("background_images", [])
            u["panel_bg_file"] = theme.get("panel_bg_file", "")
            u["panel_bg_sound"] = bool(theme.get("panel_bg_sound", False))
            u["hub_bg_mode"] = theme.get("hub_bg_mode", "none")
            u["hub_bg_file"] = theme.get("hub_bg_file", "")
            u["hub_bg_sound"] = bool(theme.get("hub_bg_sound", False))
            break
            
    await async_save_ui_data(hass, {"users": users}, entry_id)
    connection.send_result(msg["id"], {"success": True})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/start_walk_test",
    vol.Optional("entry_id"): str,
    vol.Optional("zone_id"): str,
    vol.Optional("mode", default="free"): vol.In(("free", "guided")),
    vol.Optional("timeout_seconds", default=900): vol.All(int, vol.Range(min=1, max=900)),
})
@websocket_api.async_response
async def ws_argus_start_walk_test(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    from .const import DOMAIN, DATA_PANELS
    from .core.walk_test import async_get_walk_test_manager, physical_test_kind
    panels = hass.data.get(DOMAIN, {}).get(DATA_PANELS, {})
    panel = panels.get(entry_id)
    ui = await async_load_ui_data(hass, entry_id)
    zones = [zone for zone in ui.get("zones", []) if zone.get("enabled", True)]
    zone_id = msg.get("zone_id")
    zone = next((zone for zone in zones if zone.get("id") == zone_id), None)
    if zone_id is not None and zone is None:
        connection.send_error(msg["id"], "not_found", "La zona ya no está disponible")
        return
    sensors = zone.get("entity_ids", []) if zone else [
        *(panel._all_sensors() if panel else []),
        *(sensor for item in zones for sensor in item.get("entity_ids", [])),
    ]

    if not panel or panel.state != "disarmed" or panel._arm_request:
        connection.send_error(msg["id"], "invalid_state", "Desarma Argus antes de iniciar la prueba")
        return

    wt_mgr = async_get_walk_test_manager(hass)
    if wt_mgr.get_session(entry_id):
        connection.send_error(msg["id"], "already_active", "Ya hay una prueba activa")
        return
    kinds = {
        sensor: kind for sensor in sensors
        if not panel._requires_immediate_trigger(sensor)
        and (kind := physical_test_kind(hass.states.get(sensor)))
    }
    sensors = sorted(kinds)
    if not sensors:
        connection.send_error(msg["id"], "no_sensors", "No hay sensores compatibles para la prueba")
        return
    session = wt_mgr.start_walk_test(
        entry_id=entry_id,
        sensors=sensors,
        timeout_seconds=msg.get("timeout_seconds", 900),
        zone_id=zone_id,
        guided_kinds=kinds if msg.get("mode") == "guided" else None,
        started_by=profile.get("name", "Usuario"),
    )
    await async_append_audit_log(
        hass, "walk_test_started", f"Prueba de sensores iniciada ({len(sensors)} sensores en monitoreo)",
        user=profile.get("name", "Usuario"), entry_id=entry_id
    )
    connection.send_result(msg["id"], session.to_dict())


@websocket_api.websocket_command({
    vol.Required("type"): "argus/stop_walk_test",
    vol.Optional("entry_id"): str,
    vol.Optional("cancel", default=False): bool,
})
@websocket_api.async_response
async def ws_argus_stop_walk_test(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    from .core.walk_test import async_get_walk_test_manager
    wt_mgr = async_get_walk_test_manager(hass)
    cancel = msg.get("cancel", False)
    report = wt_mgr.stop_walk_test(entry_id, reason="cancelled" if cancel else "finished")
    if report:
        tested = report.get("tested_count", 0)
        total = report.get("total_sensors", 0)
        await async_append_audit_log(
            hass, "walk_test_cancelled" if cancel else "walk_test_completed",
            f"Prueba de sensores cerrada: {tested} de {total} sensores verificados",
            user=profile.get("name", "Usuario"), entry_id=entry_id
        )
    connection.send_result(msg["id"], report or {"active": False})


@websocket_api.websocket_command({
    vol.Required("type"): "argus/get_walk_test_status",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_get_walk_test_status(hass, connection, msg) -> None:
    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    from .core.walk_test import async_get_walk_test_manager
    wt_mgr = async_get_walk_test_manager(hass)
    connection.send_result(msg["id"], wt_mgr.status(entry_id))


@websocket_api.websocket_command({
    vol.Required("type"): "argus/subscribe_walk_test",
    vol.Required("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_subscribe_walk_test(hass, connection, msg):
    from homeassistant.core import callback

    entry_id = _resolve_entry_id(hass, msg["entry_id"])
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return

    @callback
    def forward(event):
        if event.data.get("entry_id") == entry_id:
            connection.send_event(msg["id"], event.data)

    connection.subscriptions[msg["id"]] = hass.bus.async_listen("argus_walk_test_updated", forward)
    connection.send_result(msg["id"])


@websocket_api.websocket_command({
    vol.Required("type"): "argus/walk_test_step",
    vol.Optional("entry_id"): str,
    vol.Required("action"): vol.In(("continue", "retry", "skip")),
})
@websocket_api.async_response
async def ws_argus_walk_test_step(hass, connection, msg):
    from .core.walk_test import async_get_walk_test_manager

    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_admin(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    manager = async_get_walk_test_manager(hass)
    session = manager.get_session(entry_id)
    try:
        if session is None:
            raise ValueError("No hay una prueba activa")
        session.control_step(msg["action"])
        manager.publish(session)
    except ValueError as err:
        connection.send_error(msg["id"], "invalid_step", str(err))
        return
    connection.send_result(msg["id"], session.to_dict())


@websocket_api.websocket_command({
    vol.Required("type"): "argus/sensor_diagnosis",
    vol.Optional("entry_id"): str,
})
@websocket_api.async_response
async def ws_argus_sensor_diagnosis(hass, connection, msg):
    from .const import DOMAIN, DATA_PANELS
    from .core.walk_test import diagnose_sensor

    entry_id = _resolve_entry_id(hass, msg.get("entry_id"))
    try:
        await _require_argus_session(hass, connection, entry_id)
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    panel = hass.data.get(DOMAIN, {}).get(DATA_PANELS, {}).get(entry_id)
    if panel is None:
        connection.send_error(msg["id"], "not_found", "No se encontró el panel")
        return
    ui = await async_load_ui_data(hass, entry_id)
    sensors = dict.fromkeys([
        *panel._all_sensors(),
        *(sensor for zone in ui.get("zones", []) if zone.get("enabled", True)
          for sensor in zone.get("entity_ids", [])),
    ])
    connection.send_result(msg["id"], [
        diagnose_sensor(sensor, hass.states.get(sensor)) for sensor in sensors
    ])


@websocket_api.websocket_command({
    vol.Required("type"): "argus/cycle_bypass",
    vol.Required("entry_id"): str,
    vol.Required("entity_id"): str,
    vol.Required("bypass"): bool,
    vol.Optional("generation"): int,
})
@websocket_api.async_response
async def ws_argus_cycle_bypass(hass, connection, msg) -> None:
    from .const import DOMAIN, DATA_PANELS

    entry_id = _resolve_entry_id(hass, msg["entry_id"])
    try:
        profile, _ = await _require_argus_admin(hass, connection, entry_id)
        panel = hass.data.get(DOMAIN, {}).get(DATA_PANELS, {}).get(entry_id)
        if panel is None:
            connection.send_error(msg["id"], "not_found", "Alarm entity not found")
            return
        await panel.async_set_cycle_bypass(msg["entity_id"], msg["bypass"], msg.get("generation"))
        await async_append_audit_log(
            hass, "sensor_bypassed" if msg["bypass"] else "sensor_reincluded",
            f'Sensor {"omitido temporalmente" if msg["bypass"] else "reincorporado"}: {msg["entity_id"]}',
            user=profile.get("name", "Argus"), entry_id=entry_id,
            metadata={"entity_id": msg["entity_id"]},
        )
    except ArgusAuthError as err:
        connection.send_error(msg["id"], err.code, err.message)
        return
    except Exception as err:
        connection.send_error(msg["id"], "action_failed", str(err))
        return
    connection.send_result(msg["id"], {"success": True})
